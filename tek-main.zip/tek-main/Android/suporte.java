/*
 * Classname             (darkbot3.0)
 *
 * Version information   (3.0)
 *
 * Date                  (06/12,15:35)
 *
 * author                (Dark YT)
 * Copyright notice      (bot com suporte a Android/Java)
